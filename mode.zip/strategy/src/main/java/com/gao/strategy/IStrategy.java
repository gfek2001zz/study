package com.gao.strategy;

public interface IStrategy {
    void algorithmlInterface();
}
