package com.gao.strategy;

public class ConcreteStrategyC implements IStrategy {

    @Override
    public void algorithmlInterface() {

        System.out.println("执行算法C");
    }
}
