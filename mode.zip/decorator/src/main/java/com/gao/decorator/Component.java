package com.gao.decorator;

public abstract class Component {

    private String addedState;

    public String getAddedState() {
        return addedState;
    }

    public void setAddedState(String addedState) {
        this.addedState = addedState;
    }

    abstract void operation();
}
