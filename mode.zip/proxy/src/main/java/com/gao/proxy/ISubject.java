package com.gao.proxy;

public interface ISubject {

    void request(String url);
}
